export const Home = ()=>{
    return (<h1>WELCOME TO MY NOTES TAKING APP</h1>)
}